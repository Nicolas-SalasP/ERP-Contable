# Refactor tests Inventario

Archivos listos para copiar en `Backend-laravel`.

## Rutas

Copiar la carpeta `tests/Feature/Inventario` sobre:

```txt
Backend-laravel/tests/Feature/Inventario
```

Copiar `tests/Concerns/PreparaInventarioTest.php` si no existe o si quieres usar esta versión.

## Borrar archivos antiguos

Si todavía existen, borrar:

```txt
Backend-laravel/tests/Unit/InventarioPermisoServiceTest.php
Backend-laravel/tests/Unit/InventarioValorizacionServiceTest.php
Backend-laravel/tests/Unit/MovimientoInventarioModelTest.php
Backend-laravel/tests/Unit/InventarioAjusteCriticoServiceTest.php
```

## Validación

```bash
composer dump-autoload
php artisan optimize:clear
php artisan test --filter=Inventario
```

## Lógica aplicada

- Todos los tests quedan bajo `Tests\Feature\Inventario`.
- Los tests API usan `PreparaInventarioTest`.
- No se crean roles ni usuarios directamente en los tests refactorizados de API.
- Se usan usuarios demo desde `InventarioPostmanSeeder` dentro del helper.
- Se asignan permisos al rol existente para simular el gestor visual de roles.
